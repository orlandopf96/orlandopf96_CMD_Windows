#!/bin/bash

# Limpiar variables de proxy (opcional)
unset http_proxy
unset https_proxy
unset ftp_proxy

# Eliminar comprimido de actualizaciones viejo
rm -f /opt/lampp/htdocs/Nod32/Nod32_Viejos.rar

# Especifica la URL del directorio web que deseas descargar
URL="http://antivirus.gid.cu/Actualizaciones/Nod32/mirror1/dll/"

# Especifica la ruta de la carpeta local donde deseas guardar los archivos
CARPETA_LOCAL="/opt/lampp/htdocs/Actualizaciones/Nod32/mirror2"

# Crear directorio si no existe
mkdir -p "$CARPETA_LOCAL"

# Descargar archivos .nup y .ver recursivamente
wget -r -np -nH --cut-dirs=1 -P "$CARPETA_LOCAL" -A .nup,.ver --execute robots=off "$URL"

# Navegar al directorio
cd "$CARPETA_LOCAL" || exit

# Generar lista de archivos para comprimir
find . -type f \( -name "*.nup" -o -name "*.ver" \) > archivos_para_comprimir.txt

# Comprimir los archivos usando tar (alternativa a RAR)
tar -czf Nod32_Viejos.tar.gz -T archivos_para_comprimir.txt

# Mover el archivo comprimido
mv Nod32_Viejos.tar.gz /opt/lampp/htdocs/Actualizaciones/Nod32/

# Limpiar (opcional)
# rm archivos_para_comprimir.txt

exit 0